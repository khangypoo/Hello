from django.http import HttpResponse
from django.shortcuts import render

def homepage (request):
  return render(request,'home.html')

def webpage2 (request):
  return render(request,'page2.html')
